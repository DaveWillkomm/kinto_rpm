# kinto-admin plugin setup

Update the `kinto-admin` version you want in the `dependencies` section of the
`package.json` file.
