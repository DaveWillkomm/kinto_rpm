.. _kinto-admin:

Kinto Admin
###########

When the built-in plugin ``kinto.plugins.admin`` is enabled in
configuration, a Web admin UI is available at ``/v1/admin/``.


* :github:`See dedicated repo <Kinto/kinto-admin/>`

.. image:: images/screenshot-kinto-admin-1.png
    :align: center

.. image:: images/screenshot-kinto-admin-2.png
    :align: center

.. image:: images/screenshot-kinto-admin-3.png
    :align: center

.. image:: images/screenshot-kinto-admin-4.png
    :align: center
