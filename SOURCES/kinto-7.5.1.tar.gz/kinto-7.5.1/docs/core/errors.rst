.. _errors:


Errors
######


.. automodule:: kinto.core.errors
    :members:
