# kinto-admin plugin setup

Update the kinto-admin version you want to use in `package.json`, then:

```
$ npm install
$ npm run build
```

And commit the updated `build` folder.
