.. _core_api:


API core module
###############


.. automodule:: kinto.core.api
    :members:
