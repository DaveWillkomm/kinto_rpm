Contributors
============

* Aaron Egaas <me@aaronegaas.com>
* Adam Chainz <adam@adamj.eu>
* Aditya Bhasin <conlini@gmail.com>
* Anh <anh.trinhtrung@gmail.com>
* Alexis Metaireau <alexis@mozilla.com>
* Andy McKay <amckay@mozilla.com>
* Aymeric Faivre <miho@miho-stories.com>
* Ayush Sharma <ayush.aceit@gmail.com>
* Balthazar Rouberol <br@imap.cc>
* Boris Feld <lothiraldan@gmail.com>
* Castro
* Chirag B. Jadwani <chirag.jadwani@gmail.com>
* Clément Villain <choclatefr@gmail.com>
* Dan Phrawzty <phrawzty+github@gmail.com>
* David Larlet <david@larlet.fr>
* Enguerran Colson <enguerran@ticabri.com>
* Eric Bréhault <ebrehault@gmail.com>
* Eric Le Lay <elelay@macports.org>
* Éric Lemoine <eric.lemoine@gmail.com>
* Ethan Glasser-Camp <ethan@betacantrips.com>
* Fil <fil@rezo.net>
* FooBarQuaxx
* Greeshma <greeshmabalabadra@gmail.com>
* Gabriela Surita <gabsurita@gmail.com>
* Hiromipaw <silvia@nopressure.co.uk>
* Indranil Dutta <duttaindranil497@gmail.com>
* Jelmer van der Ploeg <jelmer@woovar.com>
* Joël Marty
* John Giannelos <johngiannelos@gmail.com>
* Julien Bouquillon <contact@revolunet.com>
* Lavish Aggarwal <lucky.lavish@gmail.com>
* Maksym Shalenyi <supamaxy@gmail.com>
* Mansimar Kaur <mansimarkaur.mks@gmail.com>
* Masataka Takeuchi <masataka.takeuchi@l-is-b.com>
* Mathieu Agopian <mathieu@agopian.info>
* Mathieu Leplatre <mathieu@mozilla.com>
* Maxime Warnier <marmax@gmail.com>
* Michael Charlton <m.charlton@mac.com>
* Michiel de Jong <michiel@unhosted.org>
* Mo Valipour <valipour@gmail.com>
* Nicolas Hoizey <nicolas@hoizey.com>
* Nicolas Perriault <nperriault@mozilla.com>
* Niraj <https://github.com/niraj8>
* Oron Gola <oron.golar@gmail.com>
* PeriGK <per.gkolias@gmail.com>
* Rektide <rektide@voodoowarez.com>
* Rémy Hubscher <rhubscher@mozilla.com>
* Rodolphe Quiédeville <rodolphe@quiedeville.org>
* Sahil Dua <sahildua2305@gmail.com>
* Shweta Oak <oakshweta11@gmail.com>
* Sofia Utsch <sofia.utsch@gmail.com>
* Sunakshi Tejwani <sunakshitejwani@gmail.com>
* Surya Prashanth <prashantsurya@ymail.com>
* SwhGo_oN
* Tarek Ziade <tarek@mozilla.com>
* Taylor Zane Glaeser <tzglaeser@gmail.com>
* Vamsi Sangam <vamsisangam@live.com>
* Varna Suresh <varna96@gmail.com>
* Wil Clouser <wclouser@mozilla.com>
* Yann Klis <yann.klis@gmail.com>
