.. _configuration:

Configuration
#############

.. toctree::
   :maxdepth: 2

   settings
   production
   good-practices
