.. _tutorials:

Tutorials
#########

.. toctree::
   :maxdepth: 1

   install
   first-steps
   synchronisation
   notifications-websockets
   notifications-custom
   authentication-github
   custom-id-generator
   permissions
   client-side-encryption
   write-plugin
   permission-setups
   app-examples
