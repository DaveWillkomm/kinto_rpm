.. _app-examples:

Application examples
####################

Usually, the best way to learn is to look at application examples!

An open Wiki page gives :github:`a complete list of apps in the wild <Kinto/kinto/wiki/App-examples>`!

.. important::

    We would be delighted to highlight demos, use-cases, tutorials,
    or applications made by the community, so don't hesitate to
    :github:`add a link to yours <Kinto/kinto/wiki/App-examples/_edit>`!
